<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index()
    {

        $cars = DB::table('cars')->get();
        $carTypes = DB::table('car_types')->get();
        return view('frontend.homepage', compact("cars", "carTypes"));
    }
}
